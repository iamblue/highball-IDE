# highball

## It is a WoT perfect IDE.

## Install

Install dependencies.

```bash
$ npm install
```

## Run

```bash
npm run hot-dev-server
npm run start-hot
```

## Package

```
npm run package
```

## License
MIT © [iamblue](https://github.com/iamblue)