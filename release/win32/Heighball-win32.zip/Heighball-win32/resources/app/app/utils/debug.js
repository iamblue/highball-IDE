import debug from 'debug'

global.dd = debug

export default debug
