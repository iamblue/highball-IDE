export default function createActions(attributes) {
  return attributes
}
