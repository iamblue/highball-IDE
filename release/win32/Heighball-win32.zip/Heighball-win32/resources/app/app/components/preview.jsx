import React from 'react';
// import {PrismCode} from 'react-prism';

var Preview = React.createClass({

  render: function() {
    return (
      <div>123
      </div>
    );
  }

});

module.exports = Preview;
