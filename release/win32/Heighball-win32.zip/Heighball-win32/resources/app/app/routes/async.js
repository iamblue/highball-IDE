module.exports = [ 'SomePage', 'ReadmePage' ]
