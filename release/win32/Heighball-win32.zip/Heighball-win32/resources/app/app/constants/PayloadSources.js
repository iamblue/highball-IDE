import keyMirror from 'keymirror'


export default keyMirror({
  SERVER_ACTION: null,
  VIEW_ACTION: null
})
