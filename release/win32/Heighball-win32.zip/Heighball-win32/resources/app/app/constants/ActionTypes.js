import keyMirror from 'keymirror';


export default keyMirror({
  // Routes
  ROUTE_CHANGE: null
});

